# Scripts

 - background.js: Has access to most chrome APIs
 - app.js: Has access to the actual tab, some chrome APIs
 - contextCommunicator.js: Has access to actual page's variables etc.

See also: https://stackoverflow.com/questions/9915311/chrome-extension-code-vs-content-scripts-vs-injected-scripts/9916089#9916089